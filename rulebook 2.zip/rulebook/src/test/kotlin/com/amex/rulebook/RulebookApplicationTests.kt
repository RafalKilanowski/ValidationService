package com.amex.rulebook

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RulebookApplicationTests {

	@Test
	fun contextLoads() {
	}

}
