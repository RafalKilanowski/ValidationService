CREATE  EXTENSION IF NOT EXISTS "uuid-ossp"

CREATE TABLE rule_group (
    id uuid DEFAULT uuid_generate_v4(),
    name VARCHAR NOT NULL,
    PRIMARY_KEY(id)
);

CREATE TABLE rule (
    id uuid DEFAULT uuid_generate_v4(),
    name VARCHAR NOT NULL,
    rule VARCHAR NOT NULL,
    rule_group_id uuid,
    PRIMARY_KEY(id),
    CONSTRAINT fk_group_rule FOREIGN KEY (rule_group_id) REFERENCES rule_group (id)
);


