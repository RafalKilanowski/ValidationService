package com.amex.rulebook

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class RulebookApplication

fun main(args: Array<String>) {
	runApplication<RulebookApplication>(*args)
}
