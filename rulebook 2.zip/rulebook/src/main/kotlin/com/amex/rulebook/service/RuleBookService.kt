package com.amex.rulebook.service

@Service
class RuleBookService {

    fun createRule() {
        val ruleBook: RuleBook = RuleBookBuilder.create()
            .addRule { rule ->
                rule.withNoSpecifiedFactType()
                    .then { f -> System.out.println("Rule Book created") }
            }
            .build()
    }
}